window.addEventListener("load", eventListeners);

function eventListeners(){
    console.log("Index.js Loaded");
}




